# CSC 436 - Project 4  
## Node.js / Express RESTful API

This project implements a simple backend API with full CRUD functionality using Node.js and Express.

---

## 🚀 How to Run the Project Locally

### 1. Install dependencies
```
npm install
```

### 2. Start the server
```
npm start
```

Server runs at:
```
http://localhost:3000
```

---

## 📌 API Endpoints (Tasks)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/tasks | Get all tasks |
| GET | /api/tasks/:id | Get task by ID |
| POST | /api/tasks | Create a new task |
| PUT | /api/tasks/:id | Update a task |
| DELETE | /api/tasks/:id | Delete a task |

---

## 🧪 Postman Testing
You may import a Postman collection that mirrors the endpoints above.

---

## 📦 Deployment
Deployable to Render / Railway / Cyclic. Make sure `PORT` is set automatically by the provider.
