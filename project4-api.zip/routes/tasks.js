const express = require("express");
const router = express.Router();
let tasks = require("../data/tasksData");

router.get("/", (req, res) => {
  res.json(tasks);
});

router.get("/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const task = tasks.find((t) => t.id === id);
  if (!task) return res.status(404).json({ error: "Task not found" });
  res.json(task);
});

router.post("/", (req, res) => {
  const { title, completed } = req.body;
  if (!title) return res.status(400).json({ error: "Title is required" });

  const newTask = {
    id: tasks.length + 1,
    title,
    completed: completed ?? false
  };

  tasks.push(newTask);
  res.status(201).json(newTask);
});

router.put("/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const idx = tasks.findIndex((t) => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Task not found" });

  const { title, completed } = req.body;
  if (!title && completed === undefined)
    return res.status(400).json({ error: "Nothing to update" });

  tasks[idx] = {
    ...tasks[idx],
    title: title ?? tasks[idx].title,
    completed: completed ?? tasks[idx].completed
  };

  res.json(tasks[idx]);
});

router.delete("/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const idx = tasks.findIndex((t) => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Task not found" });

  const deleted = tasks.splice(idx, 1);
  res.json({ message: "Task deleted successfully", deleted: deleted[0] });
});

module.exports = router;