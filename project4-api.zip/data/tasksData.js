let tasks = [
  { id: 1, title: "First Task", completed: false },
  { id: 2, title: "Second Task", completed: true }
];

module.exports = tasks;